<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Primeiro exemplo</title>
</head>

<body>
<?php
$largura = isset($_GET['largura'])?intval($_GET['largura']):"200";
$altura = isset($_GET['altura'])?intval($_GET['altura']):"800";
?>
	<form action="" method="get">
    	Largura: <input name="largura" type="text" value="<?php echo $largura ?>" size="100"/> <br />
		Altura: <input name="altura" type="text" value="<?php echo $altura ?>" size="100"/>
        <input type="submit" value="Criar imagem" />
    </form>
	<p>Somente números.</p>
	<img src="timthumb.php?src=foto.jpg&h=<?php echo $altura ?>&w=<?php echo $largura ?>"  />
</body>
</html>
